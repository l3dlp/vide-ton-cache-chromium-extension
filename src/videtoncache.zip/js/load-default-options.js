(function(){
	localStorage['data_to_remove']	= localStorage['data_to_remove'] || JSON.stringify({"cache":true,"localStorage":true,"indexedDB":true,"webSQL":true});
})();